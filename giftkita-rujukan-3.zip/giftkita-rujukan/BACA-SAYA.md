# GiftKita — Pakej Rujukan (24 September 2026)

Salinan penuh laman GiftKita (www.giftkita.com). Upload zip ni dalam sesi Claude baru
bila perlu rujukan. Folder ni sama susunan dengan repo:
fail HTML/JS di **root**, fungsi server dalam **`api/`** (Vercel).

> Fail yang ditanda **(sesi ini)** ialah versi yang Claude ubah pada 23–24 Sep 2026.
> Kalau fail tu belum diupload ke GitHub, versi live masih versi lama.

---

## 1. Peta halaman

**Laman utama & umum**

| Fail | Guna |
|---|---|
| `index.html` (sesi ini) | Laman utama. Simpan `?ref=` affiliate + cap masa, kira klik ke `affiliate_clicks` |
| `buat-kad.html` | Pilih tema **Hari Jadi** → Scrapbook / Merah Klasik / Butterfly |
| `kad-harijadi.html` | Pemilih tema hari jadi versi lama (bawa `?ref=`) |
| `buat-kad-anniversary.html` | Pilih tema **Anniversary** → Our Story / A Special Letter / Fiona |
| `buat-kad-graduasi.html` (sesi ini) | Pilih tema **Graduasi** → Skrol / Navy & Emas / Graduate Memory |
| `bayar.html` | Selepas bayar: panggil `/api/verify`, papar link kad, QR, WhatsApp |
| `semak-kad.html` (sesi ini) | "Semak Kad Saya": cari kad guna email + no. telefon (format tak kisah) |
| `polisi-refund.html` (sesi ini) | Polisi refund BM/EN (tiada refund tukar fikiran, tahan 14 hari mohon) |
| `affiliate.html` (sesi ini) | Daftar affiliate (RM10, Malaysia sahaja). Lepas log masuk → **dashboard penuh**: boleh tuntut / ditahan / dalam proses, link, klik, jualan, kadar jualan, carta komisen 30 hari / 6 bulan (`series` dari `api/affiliate-verify.js`), jualan terkini, sejarah tuntutan, tukar password |
| `admin.html` (sesi ini) | **Dashboard admin** (tab Ringkasan / Jualan / Affiliate / Tuntutan / Tetapan): hasil & jualan ikut tempoh 7H/30H/12B/Semua, carta hasil, pecahan pakej/template/cara bayar, senarai jualan + CSV, kedudukan affiliate, tuntutan "Sudah Transfer", reset password affiliate. Semua guna `/api/admin` (action `dashboard`, `mark_paid`, `reset_pass`) + `ADMIN_TOKEN` |
| `diagnostik.html` | Ujian sambungan Supabase / API |

**Borang → viewer** (nilai `template` dalam `collectData()` MESTI sama dengan nama viewer `card-<template>-1.html`)

| Borang | Viewer | template | Produk |
|---|---|---|---|
| `buat-kad-scrapbook.html` | `card-befday-1.html` | befday (theme: scrapbook) | Hari Jadi — Scrapbook |
| `buat-kad-merah.html` | `card-befday-1.html` | befday (theme: merah) | Hari Jadi — Merah Klasik |
| `buat-kad-butterfly.html` | `card-butterfly-1.html` | butterfly | Hari Jadi Butterfly |
| `buat-kad-anniversary-ourstory.html` | `card-anniversary-1.html` | anniversary | Our Story (19 gambar) |
| `buat-kad-suratcinta.html` | `card-suratcinta-1.html` | suratcinta | A Special Letter (10 gambar) |
| `buat-kad-fiona.html` | `card-fiona-1.html` | fiona | Fiona mixtape |
| `buat-kad-skrol.html` | `card-skrol-1.html` | skrol | Graduasi Skrol Ijazah (11 gambar) |
| `buat-kad-gradnavy.html` | `card-gradnavy-1.html` | gradnavy | Graduasi Navy & Emas |
| `buat-kad-gradmemory.html` (sesi ini) | `card-gradmemory-1.html` (sesi ini) | gradmemory | Graduate Memory (14 gambar, 8 muka) |
| `bouquet-muka.html` | `card-bouquet-1.html` | bouquet | Bouquet Muka (gambar download) |

`card-graduasi-1.html` = Memory Book lama (dah dibuang dari pemilih). **Jangan padam**, kad yang dah dijual masih guna.
`card-merah-1.html` = viewer lama; Merah Klasik sekarang guna `card-befday-1.html`.

**Skrip kongsi (root):** `gk-notis.js` (notis & penyelenggaraan, lihat bahagian 3b), `gk-bayar.js` (enjin bayaran, sesi ini), `album.js` (album PDF), `lightbox.js` (zum gambar).

---

## 2. Bayaran

| Pelan | Malaysia (ToyyibPay: FPX / DuitNow QR) | Luar negara (Stripe: kad / Apple Pay / Google Pay) |
|---|---|---|
| Basic | RM6 | $8 |
| Premium | RM8 | $10 |
| Bouquet Muka | RM3 | $3 |

- DuitNow QR: caj RM1 ditanggung customer. FPX tiada caj.
- Mata wang dikesan ikut **zon masa telefon** (Asia/Kuala_Lumpur, Asia/Kuching = RM). Butang "Malaysia / Luar negara" sebagai sandaran.
- **`STRIPE_ON = false`** dalam `gk-bayar.js` sekarang. Selagi false, semua customer nampak RM. Test USD dengan `?cur=usd`.
- Harga SEBENAR ditentukan server: `api/create-bill.js` (RM, dalam sen) dan `api/create-checkout.js` (USD, dalam sen).
- Jualan USD: `bill_code` = id sesi Stripe (`cs_…`). Jumlah dalam jadual `sales` disimpan dalam **RM sebenar** yang Stripe terima.

**Aliran:** borang → `gk-bayar.js` insert `cards` (paid:false) → `/api/create-bill` atau `/api/create-checkout` → bayar →
`bayar.html?id=…` → `/api/verify` sahkan (ToyyibPay atau Stripe) → `paid:true` + rekod `sales` + `commissions`.
Sandaran: `/api/callback` (ToyyibPay) dan `/api/stripe-webhook` (Stripe).

---

## 3. Affiliate

- Yuran RM10 (ToyyibPay), **Malaysia sahaja** (no. telefon 01x / +60).
- Komisen RM2 setiap kad (bouquet tiada komisen). Jualan USD pun dapat RM2.
- Kod `?ref=` luput **30 hari** selepas klik terakhir.
- Komisen **ditahan 7 hari** sebelum boleh dituntut. `HARI_TAHAN` ada dalam `api/affiliate-verify.js` DAN `api/withdraw-request.js`; kedua-dua MESTI sama.
- Tuntutan (`api/withdraw-request.js`) hanya ambil komisen yang dah lepas 7 hari, dan tanda `paid_out` ikut id komisen tersebut sahaja.
- Minimum tuntutan RM10. Maklumat bank diingat dalam telefon affiliate.
- Password wajib. Affiliate lama tanpa password → tetapkan sendiri guna no. WhatsApp (`api/affiliate-setpass.js`).
  Tukar password: butang "Tukar Password" dalam dashboard (`api/affiliate-setpass.js` dengan `oldPassword`).
  Lupa password → affiliate WhatsApp admin → admin reset di `admin.html` (`api/admin.js`, action `reset_pass`) → hantar password sementara melalui butang WhatsApp.
- Password disimpan sebagai `sha256('gk::'+password)` dalam `affiliates.pass_hash`.

---

## 3b. Notis & Penyelenggaraan

- Dikawal dari `admin.html` → tab **Tetapan** → "Notis & Penyelenggaraan". Disimpan dalam jadual Supabase `settings` (baris `key='notice'`).
- `gk-notis.js` dipasang (sebelum `</body>`) di: `index.html`, `buat-kad.html`, `buat-kad-anniversary.html`, `buat-kad-graduasi.html`,
  `kad-harijadi.html`, semua borang `buat-kad-*.html`, `bouquet-muka.html`, `semak-kad.html`, `affiliate.html`.
  **JANGAN** pasang di `card-*-1.html` (penerima kad) atau `bayar.html`.
- **Template baru:** tambah `<script src="gk-notis.js" defer></script>` di borang baru, dan tambah namanya dalam `TPL_BORANG` di `admin.html`.
- Fungsi: banner di atas page; borang template yang ditanda → skrin "sedang diselenggara"; link ke template itu dapat lencana 🔧;
  "Tutup SEMUA tempahan" sekat semua borang (Semak Kad & Affiliate tetap buka).
- Data awam: `GET /api/admin?notis=1` (dicache 30s). Dikongsi dalam `api/admin.js` supaya tak tambah fungsi Vercel (had Hobby = 12; sekarang 11).
- **SQL sekali sahaja** (Supabase → SQL Editor):
  ```sql
  create table if not exists public.settings (
    key text primary key,
    value jsonb not null default '{}'::jsonb,
    updated_at timestamptz default now()
  );
  alter table public.settings enable row level security;
  ```
  (Tiada policy = hanya server dengan service key boleh baca/tulis.)

## 4. Jadual Supabase (yang diketahui)

- `cards`: id, card_data (json), paid, ref_code, buyer_name, buyer_email, buyer_phone, bill_code, amount, plan, created_at
- `sales`: id, card_id, ref_code, amount, bill_code, status, created_at
- `commissions`: affiliate_code, sale_id, amount, paid_out, created_at
- `affiliates`: code, name, email, whatsapp, active, commission_flat, bill_code, pass_hash
- `affiliate_clicks`: code
- `withdrawals`: id, affiliate_code, amount, status, bank_name, bank_account, account_name, created_at, paid_at
- `settings`: key, value (jsonb), updated_at (notis & penyelenggaraan)

Had saiz satu baris `cards` ≈ 4.5MB (gambar dikecilkan dalam borang; semak `kiraSaiz()`).

---

## 5. Environment Variables Vercel

| Nama | Untuk |
|---|---|
| `SUPABASE_URL`, `SUPABASE_SERVICE_KEY` | Semua fungsi `api/` |
| `SITE_URL` | https://www.giftkita.com |
| `TOYYIBPAY_SECRET`, `TOYYIBPAY_CATEGORY`, `TOYYIBPAY_BASE` | ToyyibPay |
| `DNQR_ENABLE`, `DNQR_CHARGE` | DuitNow QR (lalai '1') |
| `STRIPE_SECRET_KEY` | Stripe (`sk_test_…` untuk test, `sk_live_…` untuk jualan) |
| `USD_MYR` | Pilihan, anggaran kadar (lalai 4.2) |
| `ADMIN_TOKEN` | `admin.html` / `api/admin` (termasuk reset password affiliate) |

---

## 6. Belum selesai / perlu tindakan

1. **Stripe live**: tunggu semakan IC lulus → `STRIPE_SECRET_KEY` = `sk_live_…` → daftar webhook live
   `https://www.giftkita.com/api/stripe-webhook` (event `checkout.session.completed`, `checkout.session.async_payment_succeeded`)
   → `STRIPE_ON = true` dalam `gk-bayar.js`.
2. Nama akaun Stripe: tukar "Gift.kita" / "Giftkita" → **GiftKita** (sandbox & live).
3. `index.html`: harga masih RM sahaja (tiada paparan USD untuk pelawat luar).

## 7. Fail yang TIADA dalam pakej ni

`vercel.json` (kalau ada). Semua fail `api/` yang wujud dah ada dalam pakej ni.
Hantar fail-fail ni dalam sesi akan datang kalau perlu ubah bahagian tu.

## 8. Dokumen lain

`docs/GIFTKITA-RUJUKAN-PENUH.md`: rujukan teknikal panjang (API `gk-bayar.js`, peraturan viewer, Bouquet sticker, dll).
Ditulis sebelum 23 Sep: bahagian Stripe, affiliate baru, Navy & Emas dan Graduate Memory ada dalam fail BACA-SAYA ni.
