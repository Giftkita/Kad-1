# GiftKita — Rujukan Penuh

> **Cara guna fail ini:** paste keseluruhan fail dalam chat baru, kemudian
> hantar video/gambar reference design. Tak perlu terangkan apa-apa lagi.
>
> **JANGAN paste fail ni ke Canva** — ia untuk Claude sahaja. Untuk Canva,
> copy satu blok prompt sahaja (Seksyen 4).

**Kandungan**

- **Bahagian A — Panduan** (peraturan tetap, ikut setiap kali)
  1. Apa itu GiftKita
  2. Peraturan tetap
  3. Bila user hantar reference design
  4. Prompt Canva — format wajib · 4.1 Bingkai gambar
  5. Ciri asas WAJIB setiap template
  6. Fail yang perlu dibina
  7. Wiring borang
  8. Wiring viewer
  9. Senarai semak sebelum hantar
  10. Bug yang pernah berlaku
  11. Gotcha operasi
  12. Gaya kerja yang dikehendaki
- **Bahagian B — Rekod template** (apa yang dah wujud)
  - B1. Inventori repo
  - B2. Template "Fiona"
  - B3. Template "Butterfly"

---

# BAHAGIAN A — PANDUAN

## 1. Apa itu GiftKita

Platform kad ucapan digital interaktif untuk pasaran Malaysia (macam gifft.me).
Customer isi borang → bayar → dapat link kad peribadi untuk dihantar ke
penerima.

- **Domain:** www.giftkita.com (canonical) — juga di kad-1.vercel.app
- **Repo:** GitHub `Kad-1`, deploy automatik ke Vercel
- **Database:** Supabase (`https://lejpuajafuenlfvlovfg.supabase.co`), simpan
  data kad sebagai JSONB
- **Bayaran:** ToyyibPay (FPX), harga tetap server-side: RM6 Basic / RM8 Premium
- **Operator:** solo. Pemasaran melalui TikTok, satu video setiap tema kad.
- **Bahasa perbualan:** Bahasa Malaysia santai.

---

## 2. Peraturan tetap (jangan tanya lagi)

1. **Satu tema = satu borang sendiri.** Jangan sesekali buat satu borang
   dikongsi yang tukar-tukar medan dalam page. Setiap tema ada fail borang
   berasingan.
2. **Kategori dengan lebih satu tema → laluan melalui halaman pemilih tema.**
   Contoh sedia ada:
   - `buat-kad.html` (pemilih Hari Jadi) → `buat-kad-merah.html`,
     `buat-kad-scrapbook.html`
   - `buat-kad-anniversary.html` (pemilih Anniversary) →
     `buat-kad-anniversary-ourstory.html`, `buat-kad-suratcinta.html`,
     `buat-kad-fiona.html`
3. **Setiap jenis kad ialah produk sendiri:** borang sendiri + viewer sendiri +
   design sendiri.
4. **Design dibuat sendiri di Canva**, bukan di-hardcode. Kerja Claude ialah
   *pemasangan* (assembly), bukan reka letak.
5. **Satu fail HTML sahaja setiap kad** — gambar latar ditanam terus sebagai
   base64. Jangan pisahkan jadi folder assets, jangan hantar zip.
6. **Setiap tempat gambar mesti ada bingkai.** Tiada slot gambar telanjang,
   dalam mana-mana tema. Detail penuh di Seksyen 4.1.

---

## 3. Bila user hantar video/gambar reference design

Langkah Claude, ikut turutan:

1. **Tonton/analisa reference — SETIAP skrin, elemen demi elemen.** Keluarkan
   frame video (1 saat sekali), lepas tu senaraikan untuk setiap skrin: apa
   di latar, apa objek besar, di mana, warna apa, teks/butang apa. Tulis
   senarai tu SEBELUM tulis prompt.
   **"Tiru sebijik" maksudnya sebijik** — jangan tukar konsep animasi, jangan
   tukar palet, jangan "perbaiki" ikut cita rasa sendiri. Kalau video tunjuk
   dinding rama-rama padat, buat dinding padat — bukan rama-rama berterbangan
   jarang sebab "lebih realistik". Kalau nak cadangkan sesuatu yang lain,
   cadang sebagai pilihan tambahan, bukan ganti.
2. **Tanya SATU soalan sahaja jika perlu:** warna tema atau nama tema. Selain
   tu, teruskan.
3. **Hasilkan prompt Canva dalam SATU fail .md** (bukan taip dalam chat).
   Format prompt ikut Seksyen 4.
   **Fail tu mesti ada blok prompt SAHAJA.** Jangan campur "struktur kad",
   "apa Claude bina dalam kod", wiring bayaran atau senarai ciri dalam fail
   yang sama — user selalu paste fail penuh, dan Canva akan baca bahagian tu
   sebagai spek app lalu bina prototaip. Nota untuk Claude simpan di fail
   berasingan.
4. Tunggu user hantar PNG hasil Canva.
5. **Pasang** ikut Seksyen 5–8.
6. **Uji** ikut senarai semak Seksyen 9 sebelum hantar.

---

## 4. Prompt Canva — format wajib

### Peraturan prompt

**Sebelum taip prompt — alat yang betul (ini punca #1 masalah):**

Canva ada DUA alat AI yang berbeza sama sekali:

| Alat | Apa dia buat | Guna? |
|---|---|---|
| Kotak **"Describe your idea"** (bawah skrin / home) = Canva Code | Bina prototaip, app, laman interaktif | **JANGAN** |
| **Magic Media / Dream Lab** (dalam editor, menu +) | Jana GAMBAR | **YA** |

Kotak "Describe your idea" memang kerjanya bina app. Bagi dia apa-apa pun —
walaupun prompt gambar yang sempurna — dia tetap bina prototaip.

Langkah betul:

1. Canva → **Create a design → Custom size** → 1080×1920 px
2. Dalam editor: **+ (Add)** → **Magic Media / Dream Lab** → **Image**
3. Paste prompt → generate

**Tanda alat betul:** dia keluar ~4 pilihan gambar untuk dipilih.
**Tanda alat salah:** dia balas "Prototaip sudah dipasang…" → undo, tukar alat.

**JANGAN paste fail .md penuh ke Canva.** Fail prompt tu untuk Claude, bukan
untuk Canva. Dalam tu ada bahagian struktur kad, wiring kod dan bayaran —
Canva akan baca semua tu dan bina app ikut spek. **Copy blok kod satu halaman
sahaja**, dari baris pertama sampai baris terakhir blok tu.

**Format prompt — guna BRIEF REKA BENTUK, bukan ayat mengalir**

Ini format yang terbukti menjadi (hasilkan kad Surat Cinta 8 halaman). Ayat
mengalir gaya "a top-down flat-lay photograph of a cream sheet of paper lying
on a table…" **tidak menjadi** — Canva abaikan separuh arahan sebab tiada
senarai jelas apa nak letak.

Prompt ditulis dalam **Bahasa Malaysia**, susun ikut rangka ni:

1. **Ayat pembuka:** "Buat reka bentuk poster/grafik statik — bukan laman web,
   bukan prototaip boleh klik. Semua elemen dilukis rata di atas kanvas macam
   poster biasa."
   *(Ya, sebut "bukan laman web" — fail yang menjadi memang ada ayat ni.)*
2. **Gaya visual** — 2–3 ayat suasana keseluruhan
3. **Palet warna** — senarai hex, tetapkan warna mana paling menonjol, dan
   senarai warna yang HARAM
4. **Kotak ruang letak** — jadual warna + peraturan bernombor (termasuk
   bingkai, Seksyen 4.1)
5. **Senarai halaman** — setiap halaman: saiz piksel, elemen sebagai
   **bullet**, dan **kiraan kotak** di hujung ("1 kotak hijau + 1 kotak
   magenta")
6. **Jumlah kotak** — kira semua sekali sebagai semakan silang
7. **Teks** — apa boleh dibakar, apa tak boleh
8. **Eksport** — PNG, 1×, 1080px, nama fail
9. **Senarai semak sebelum eksport** — soalan bernombor untuk user semak
   sendiri

Kiraan kotak tu yang paling penting — tanpa nombor, Canva letak ikut suka.

Lain-lain:
- Satu halaman satu masa. Paste bahagian halaman tu sahaja, semak, baru
  sambung.
- Untuk pembetulan: **"Edit this existing design. Do not create a new design"**
  dan senaraikan tepat apa nak ubah/buang.

### Kotak ruang letak (slot) — konvensyen tetap

Canva letak **segi empat warna rata** di mana kandungan dinamik akan masuk.
Claude auto-detect warna ni dan tindih dengan kandungan sebenar.

| Kegunaan | Warna |
|---|---|
| Gambar customer | Magenta `#FF00FF` |
| Video YouTube | Cyan `#00FFFF` |
| Ruang ucapan/surat | Hijau `#00FF00` |
| Kejutan | Kuning `#FFFF00` |

Peraturan kotak:
- Warna rata sepenuhnya — tiada gradient, bayang, kelegapan
- **Setiap slot gambar WAJIB ada bingkai hiasan** — lihat Seksyen 4.1
- Tiada dua kotak bersentuhan atau bertindih
- Jarak ≥25px antara slot; ≥40px dari garis tengah (untuk design spread)

### 4.1 Bingkai gambar — WAJIB, jangan tanya lagi

**Tiada satu pun slot gambar boleh keluar sebagai kotak kosong.** Setiap slot
magenta `#FF00FF` mesti ada bingkai yang dilukis mengelilinginya dalam design
Canva. Gambar customer tanpa bingkai nampak macam tampalan, bukan kad.

Sama juga untuk slot video `#00FFFF` dan slot kejutan `#FFFF00` — bingkai ikut
gaya yang sama supaya satu tema nampak sekeluarga.

**Pilihan bingkai (pilih SATU keluarga untuk satu tema, jangan campur):**

| Gaya | Sesuai untuk |
|---|---|
| Polaroid (border putih tebal, bawah lebih tebal) | scrapbook, best friend, hari jadi |
| Bingkai emas berukir | anniversary, nikah, graduasi |
| Jalur filem (sprocket kiri-kanan) | mixtape, throwback, couple |
| Kertas koyak / deckle edge | vintage, surat cinta |
| Arch / oval / bulat | minimal, moden, bunga |
| Sudut tape washi atau photo corner | scrapbook, journal |
| Renda / lace | romantik lembut |

**Bingkai mana untuk slot mana — jangan tertukar:**

| Slot | Warna | Layanan |
|---|---|---|
| Gambar customer | magenta `#FF00FF` | bingkai penuh — polaroid, emas, jalur filem |
| Video | cyan `#00FFFF` | bingkai sama keluarga dengan gambar |
| Ucapan / surat | hijau `#00FF00` | kertas, nota koyak, kad — **bukan** bingkai gambar |
| Kejutan | kuning `#FFFF00` | ikut konteks design |

Bingkai polaroid/gambar di sekeliling slot **hijau** nampak salah — macam
gambar tulisan. Slot teks duduk atas kertas, bukan dalam bingkai gambar. Dan
jangan letak dua bingkai bertindih (contoh: bingkai polaroid dalam nota koyak).

**Peraturan teknikal bingkai:**

1. Bingkai dilukis **di LUAR** kotak magenta. Kotak magenta itu sendiri ialah
   **bukaan gambar sebenar** — saiz tepat, warna rata, tiada apa-apa di atasnya.
2. Tebal bingkai **≥20px** (1080px lebar) supaya tak hilang bila kecilkan di
   telefon.
3. Kalau bukaan bukan segi empat (oval, arch, bulat, hati) — **tulis dalam
   prompt** bentuk apa. Claude akan padan `clip-path`/`border-radius` ikut
   bentuk tu. Kotak magenta kekal segi empat penuh; bentuk datang dari bingkai.
4. Hiasan yang **melintas atas gambar** (tape, klip kertas, bunga kering,
   reben) — **JANGAN** lukis atas kotak magenta. Senaraikan je dalam nota
   prompt; Claude lukis balik dalam HTML supaya ia duduk di atas gambar
   customer, bukan tertutup olehnya.
5. Bingkai boleh senget (±3–8°) untuk gaya scrapbook — kotak magenta senget
   sekali, ikut bingkai.
6. Nisbah bukaan kena konsisten dengan apa yang borang minta (Seksyen 7.5) —
   kalau bukaan 4:5, kotak laras dalam borang pun 4:5.

**Ayat siap pakai untuk prompt Canva:**

> Each photo placeholder must sit inside a decorative [polaroid / ornate gold /
> film strip] frame. Draw the frame AROUND the flat magenta `#FF00FF` rectangle
> — the magenta rectangle itself stays completely flat and empty, nothing
> overlapping it. Frame border at least 20px thick. Do not place any tape,
> clip, or flower on top of the magenta area.

### Teks

- **BOLEH dibakar dalam gambar:** tajuk seksyen hiasan yang kekal untuk semua
  pengguna (cth "Love Letters — For You")
- **JANGAN dibakar:** nama, tarikh, isi ucapan/surat — ini berubah setiap
  pengguna
- **JANGAN letak nombor halaman** ("Page 3 of 8") — kad papar sendiri
- Kalau tema perlu **dwibahasa EN/BM**, tajuk pun JANGAN dibakar — biar latar
  kosong, Claude tindih teks guna HTML

### Eksport

PNG, 1×, lebar tetap (1080px untuk portrait scroll; 2000×1545 untuk spread
flip-book), setiap halaman berasingan.

---

## 5. Ciri asas WAJIB setiap template

Tiada satu pun boleh tertinggal, tak perlu diingatkan:

- [ ] Gambar customer (bilangan ikut design) — **setiap satu dalam bingkai**
      (Seksyen 4.1). Slot gambar tanpa bingkai = design belum siap.
- [ ] Link video YouTube
- [ ] Muzik — **kedua-dua** link YouTube DAN upload MP3
- [ ] Album PDF (`album.js`)
- [ ] Slaid kejutan/surprise
- [ ] Butang pratonton percuma
- [ ] Bayaran melalui `gk-bayar.js`
- [ ] Toggle bahasa EN/BM

---

## 6. Fail yang perlu dibina untuk template baru

Guna nama tema, contoh tema `nikah`:

```
buat-kad-nikah.html      ← borang order
card-nikah-1.html        ← viewer kad
```

**Peraturan penamaan kritikal:** viewer MESTI `card-<template>-1.html`, di mana
`<template>` sama persis dengan nilai `template:` dalam borang. Sistem
(`bayar.html`, `semak-kad.html`) jana link automatik dari corak ni — kalau tak
padan, customer dapat kad salah.

Kalau kategori tu baru ada tema kedua, tukar borang sedia ada jadi pemilih tema
(lihat Seksyen 2).

**Tiada fail sistem lain perlu diubah** — `index.html`, `bayar.html`,
`semak-kad.html`, `api/*` semua sudah generik.

---

## 7. Wiring borang (`buat-kad-<tema>.html`)

### 7.1 Head — WAJIB ada SDK Supabase

```html
<script src="https://unpkg.com/@supabase/supabase-js@2"></script>
<script>if(!window.supabase){document.write('<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"><\/script>');}</script>
```

### 7.2 Body — dua div ini, pratonton DULU

```html
<div id="gk-pratonton"></div>
<div id="gk-bayar"></div>
<script src="gk-bayar.js"></script>
```

### 7.3 `collectData()` — MESTI sync (return terus)

```js
function collectData(){
  var d = { template:'nikah' };      // ← WAJIB, sama dengan nama fail viewer
  // ... isi medan lain
  return d;                           // ← MESTI return, JANGAN guna callback
}
```

**Kenapa penting:** `gk-bayar.js` panggil fungsi ni macam fungsi biasa. Kalau
guna callback (`collect(cb)`), enjin bayaran dapat `undefined` → butang bayar
nampak jalan tapi tak masuk ToyyibPay langsung.

Proses fail (MP3, gambar) mesti dibuat semasa **event upload**, disimpan dalam
variable, bukan semasa `collectData()` dipanggil.

### 7.4 Mount

```js
GKBayar.mount({
  el:'gk-bayar',            // ← string ID, BUKAN element
  previewEl:'gk-pratonton', // ← string ID
  viewer:'card-nikah-1.html',
  collect:collectData,
  produk:'Kad Nikah',
  qr:true                   // ← true (DuitNow QR sudah aktif)
});
```

**API sebenar `gk-bayar.js` (disahkan dari fail, Sep 2026):**

| Perkara | Fakta |
|---|---|
| `el` / `previewEl` | `getElementById(CFG.el)` — **string ID sahaja**. Beri `'#gk-bayar'` → `null` → `mount()` **senyap tak buat apa-apa**, tiada ralat console |
| `collect()` | dipanggil terus, sync. Return `null` → `card_data:null` **tetap masuk Supabase** dan customer tetap dibawa ke pembayaran |
| Penjaga data | **TIADA**. `gk-bayar.js` tak semak sama ada data sedia. Borang sendiri kena matikan `#gkb-pay` dan `#gkb-prev` |
| Had saiz | `pay()` tolak kalau `JSON.stringify(collect()).length/1024 > 4500` |
| Pratonton | simpan `localStorage.gk_preview`, buka `CFG.viewer+'?preview=1'`. Kalau penuh, cuba semula tanpa `mp3` |
| Pelan | Lalai Basic RM6 / Premium RM8. Sejak Sep 2026 borang boleh ganti: `plans:{ bouquet:{rm:3,nm:'…',ds:'…'} }` — satu pelan = tiada pilihan, terus ringkasan. Teks butang: `btn:'Bayar RM3 & download'`. **Kunci pelan dihantar ke `/api/create-bill` — server MESTI ada harga untuk kunci tu**, kalau tak bil ToyyibPay salah |
| `qr:true` | hanya papar cip DuitNow QR + nota caj RM1 pada **cara bayaran**, bukan ciri kad |
| Baris Supabase | `{card_data, paid:false, ref_code, buyer_name, buyer_email, buyer_phone}` — `plan` dihantar ke `/api/create-bill`, bukan disimpan dalam baris |
| `GKBayar.buyer()` | boleh dipanggil selepas mount untuk dapat `{name,email,phone,plan}` |

**Tambah produk dengan harga baru — 4 tempat, semua kena selari:**

| Fail | Apa | Kunci contoh |
|---|---|---|
| borang | `GKBayar.mount({ plans:{ bouquet:{rm:3,…} } })` | `bouquet` |
| `api/create-bill.js` | `PRICES.bouquet = 300` (SEN), `PLAN_NAME`, `PLAN_DESC` — **ini yang tentukan bil ToyyibPay**, bukan borang | `bouquet` |
| `api/callback.js` **DAN** `api/verify.js` | `TIADA_KOMISEN = { bouquet:true }` dalam **kedua-dua** fail. Dua-dua rekod jualan + komisen (callback dari ToyyibPay, verify dari bayar.html), berlumba, idempotent ikut `bill_code`. Tukar satu je → komisen bocor melalui yang satu lagi | `bouquet` |
| `bayar.html` | `PRODUK_DOWNLOAD = { bouquet:'Bouquet' }` untuk produk download (tiada link kongsi/WhatsApp/QR). Ayat baru **mesti** masuk `GK_DICT` dan tukar `data-ms` bukan `textContent` sahaja — lapisan terjemahan tulis balik dari `data-ms` | `bouquet` |

Papan affiliate (`affiliate.html` + `affiliate-verify.js`) kira jualan dari jadual `commissions` sahaja — produk tanpa komisen **tak muncul langsung**, bukan RM0. Tiada perubahan diperlukan di situ selain nota telus.

`create-bill.js` tolak pelan yang tak dikenali (`!PRICES[plan]` → 400 "Data tak lengkap"). Jadi kalau lupa server, customer nampak ralat, bukan bil salah — selamat tapi jualan hilang.

**Produk gambar (bouquet) — JANGAN pasang `previewEl`.** `preview()` simpan output
`collect()` ke localStorage dan buka viewer — untuk bouquet itu gambar BERSIH tanpa
tanda air. Customer screenshot, tak bayar. Pratonton bertanda air dalam borang dah cukup.

Corak matikan butang sampai data sedia:

```js
function kemasBayar(){
  var sedia = /* data betul-betul sedia? */;
  ['gkb-pay','gkb-prev'].forEach(function(id){
    var b=document.getElementById(id); if(b) b.disabled=!sedia;
  });
}
GKBayar.mount({...}); kemasBayar();   // panggil semula setiap kali data berubah
```

Tambah fallback kalau `gk-bayar.js` tak dijumpai:

```js
if(window.GKBayar){ GKBayar.mount({...}); }
else {
  document.getElementById('gk-bayar').innerHTML =
    '<div style="padding:14px 16px;background:#ffebee;border:1.5px solid #ef9a9a;'
   +'border-radius:12px;font-size:.82rem;color:#c62828">Fail <b>gk-bayar.js</b> '
   +'tidak dijumpai. Pastikan ia di root repo, bukan dalam folder api.</div>';
}
```

### 7.5 Gambar

- Resize ke **650–800px**, quality 0.8. **JANGAN** 1200px — 10 gambar besar
  boleh gagal simpan (had baris Supabase ~4.5MB).
- Kalau slot bernombor tetap (setiap slot posisi khusus dalam design): kekalkan
  kotak bernombor "Foto 1–N" + butang "Isi beberapa sekali gus".
- Upload terus simpan. **Jangan** paksa popup laras selepas setiap gambar —
  laras hanya bila user tap gambar yang sudah ada.
- Bagi setiap slot, simpan nisbah frame sebenar supaya kotak laras sama bentuk
  dengan hasil akhir.
- Tandakan dengan jelas slot mana untuk kejutan (cth "Foto 10 ❤" + nota).

---

## 8. Wiring viewer (`card-<tema>-1.html`)

### 8.1 Head — SDK Supabase sama macam borang

### 8.2 Sambungan database + muat data — WAJIB

```js
var SB_URL='https://lejpuajafuenlfvlovfg.supabase.co';
var SB_KEY='sb_publishable_igFE4w_dz4ZF99wH1LeBKg_JL5kFoZ0';
var db=null; try{ if(window.supabase&&window.supabase.createClient) db=window.supabase.createClient(SB_URL,SB_KEY);}catch(e){}

(function init(){
  var p=new URLSearchParams(location.search);
  if(p.get('preview')==='1'){ try{D=JSON.parse(localStorage.getItem('gk_preview'))}catch(e){D=null}
    if(!D||!Object.keys(D).length)D=DEMO; bina(); badge(); return; }
  var id=p.get('id');
  if(!id){ D=DEMO; bina(); badge(); return; }
  if(!db){ gagal('Sambungan ke pangkalan data gagal. Sila refresh halaman.'); return; }
  db.from('cards').select('card_data,paid').eq('id',id).single().then(function(r){
    if(r.error) throw r.error;
    if(r.data.paid!==true){ gagal('Kad ini belum diaktifkan. Sila selesaikan pembayaran untuk membukanya.'); return; }
    D=r.data.card_data; bina();
  }).catch(function(){ gagal('Kad tidak dijumpai atau telah tamat tempoh.'); });
})();
```

**Tanpa blok ni, kad akan papar data DEMO kosong walaupun customer dah isi
borang dan bayar.** Ini bug yang pernah berlaku — jangan ulang.

### 8.3 Muzik — MESTI dipanggil dalam gesture klik

```js
function bukaKad(){
  if(dahBuka)return; dahBuka=true;
  muzik();                    // ← TERUS, jangan letak dalam setTimeout
  // ... animasi boleh jalan selepas ni
}
```

**Kenapa:** browser blok autoplay kalau ia tak berlaku serta-merta dalam
gesture pengguna. Kalau `muzik()` dipanggil selepas animasi habis (1–2 saat),
lagu takkan main langsung.

Sokong kedua-dua: `D.mp3` (base64 audio) dan `D.yt` (link YouTube, main melalui
hidden `#yt-root` player).

### 8.4 Album PDF

```js
GKAlbum.init(D);
```

`album.js` baca **nama medan Hari Jadi sahaja**: `title`, `subtitle`, `wishes`,
`cake_img`, `p1_img`–`p6_img`, `quote`, `author`, `story`, `story_img`,
`surprise_msg`.

Template dengan nama medan lain **mesti map dulu** sebelum panggil. **JANGAN
edit `album.js`** — ia dikongsi dengan kad yang sudah dijual.

### 8.5 Dwibahasa EN/BM

Kalau tajuk tidak dibakar dalam gambar Canva: simpan kamus `TXT={en:{...},
ms:{...}}`, tindih guna div `position:absolute` dengan koordinat peratusan,
toggle butang EN/BM di penjuru.

### 8.6 Pasang gambar dalam bingkai

Gambar customer duduk **dalam bukaan** (kotak magenta yang dikesan), bukan atas
bingkai:

```css
.slot{position:absolute;overflow:hidden}      /* koordinat % dari slot magenta */
.slot img{width:100%;height:100%;object-fit:cover;display:block}
```

- Bukaan bukan segi empat → tambah `border-radius` (bulat/oval) atau
  `clip-path` (arch, hati) pada `.slot`.
- Hiasan yang patut berada **atas** gambar (tape, klip, bunga kering) dilukis
  selepas `.slot`, `z-index` lebih tinggi.
- Bingkai senget → putar `.slot` guna `transform:rotate()` dengan sudut sama
  macam design.
- Slot kosong (customer tak isi) → papar bingkai dengan latar kertas lembut,
  **jangan** biar kotak magenta terkelip keluar.

---

## 9. Senarai semak sebelum hantar

Uji setiap satu, jangan andaikan:

**Borang**
- [ ] `collectData()` return objek (bukan undefined) — test dalam console
- [ ] `template:` ada dan sama dengan nama fail viewer
- [ ] Butang pratonton buka viewer dengan `?preview=1`
- [ ] Upload banyak gambar sekali gus — semua masuk, tiada tersekat
- [ ] Toggle EN/BM tukar semua label, placeholder, dan tajuk
- [ ] Tiada error dalam console

**Viewer**
- [ ] Buka dengan `?id=<uuid>` sebenar → papar data customer, tiada badge
      PRATONTON
- [ ] Kad belum bayar → papar mesej "belum diaktifkan"
- [ ] Gambar keluar di slot betul, kedudukan laras terpakai
- [ ] Setiap gambar ada bingkai; bentuk gambar padan dengan bentuk bukaan
      (bulat/arch/hati bukan segi empat)
- [ ] Tiada warna slot (magenta/cyan/hijau/kuning) terkelip keluar di mana-mana
- [ ] Lagu YouTube main; lagu MP3 main
- [ ] Video YouTube buka overlay
- [ ] Kejutan tersorok sampai ditekan
- [ ] Album PDF boleh muat turun
- [ ] Toggle EN/BM berfungsi

**Hujung ke hujung**
- [ ] Beli → link yang diterima ialah `card-<template>-1.html`, bukan befday
- [ ] Semak Kad → link betul, butang QR keluar untuk Premium sahaja

---

## 10. Bug yang pernah berlaku — jangan ulang

| Bug | Punca | Pencegahan |
|---|---|---|
| Kad kosong lepas bayar | Viewer tiada kod baca Supabase | Seksyen 8.2 |
| Butang bayar tak masuk ToyyibPay | `collect()` guna callback, bukan return | Seksyen 7.3 |
| Customer dapat kad Hari Jadi walau beli tema lain | Borang tak set `template` | Seksyen 7.3 |
| QR Premium tak keluar di Semak Kad | `recover.js` baca plan dari `card_data`, bukan lajur `plan` | Sudah dibaiki |
| Lagu YouTube tak main | `muzik()` dipanggil lepas animasi, di luar gesture | Seksyen 8.3 |
| "Sambungan ke pangkalan data gagal" | SDK Supabase tak dimuat dalam borang | Seksyen 7.1 |
| Canva tak ikut prompt, letak elemen ikut suka | Prompt ditulis sebagai ayat mengalir, bukan brief bernombor dengan kiraan kotak | Seksyen 4 |
| Canva bina website sebenar, bukan gambar | Taip dalam kotak AI home Canva, atau prompt tak nyatakan "poster/grafik statik" | Seksyen 4 |
| Canva balas "Prototaip sudah dipasang", bina app lengkap dengan toggle & JSON | Guna kotak "Describe your idea" (Canva Code), bukan Magic Media | Seksyen 4 |
| Canva bina app ikut spek penuh kad | Paste fail .md penuh, bukan blok prompt satu halaman | Seksyen 4 |
| Canva bina app walaupun blok prompt bersih | Fail prompt ada bahagian "struktur kad"/"apa Claude bina" — buang, asingkan | Seksyen 3 |
| Design siap tapi tak sama dengan video reference | Claude reka ikut idea sendiri (tukar animasi, tukar palet) tanpa senaraikan skrin video dulu | Seksyen 3 |
| Data gagal simpan bila banyak gambar | Resize 1200px terlalu besar | Seksyen 7.5 |
| Gambar nampak macam tampalan, kad hambar | Slot gambar tanpa bingkai | Seksyen 4.1 |
| Tape/klip hilang bawah gambar customer | Hiasan dilukis atas kotak magenta | Seksyen 4.1 |
| Borang tanpa SDK Supabase dalam `<head>` | `gk-bayar.js` baca `window.supabase` masa ia LOAD → `db=null` → butang bayar keluar "Sambungan ke pangkalan data gagal". Halaman nampak elok sepenuhnya sampai customer tekan bayar | Seksyen 7.1 — dua baris SDK WAJIB, sebelum `gk-bayar.js` |
| Fail lama kekal live lepas upload | GitHub app cipta salinan bernombor (`buat-kad-40.html`) | Seksyen 11 |

---

## 11. Gotcha operasi

- **Supabase free tier auto-pause selepas ~1 minggu melahu.** Site nampak
  elok tapi setiap checkout gagal "Failed to fetch" — jualan hilang senyap.
  Buka dashboard Supabase sekali seminggu.
- **Upload dari telefon boleh cipta salinan bernombor.** GitHub app kadang
  simpan `buat-kad-40.html` dan biarkan `buat-kad.html` lama kekal live.
  Semak senarai fail selepas upload; padam yang lama, rename yang baru.
- **`gk-bayar.js`, `album.js`, `lightbox.js` mesti di ROOT repo**, bukan dalam
  `api/`. Pernah tersalah letak → 404.
- **API_BASE mesti relatif (`''`) di domain sendiri.** Hardcode host bukan
  canonical menyebabkan redirect cross-origin dan "Failed to fetch".
- **GitHub "can't show files this big"** hanya limitasi paparan — fail tetap
  berfungsi. Abaikan.
- **QR WhatsApp tak boleh baca QR URL.** Guna Google Lens atau kamera telefon
  untuk uji.
- `lightbox.js` dirujuk oleh viewer tapi pernah hilang dari repo — isu lama,
  bukan keutamaan.

---

## 12. Gaya kerja yang dikehendaki

- Buat suntingan kod **terus** dan hantar fail siap — jangan terangkan apa nak
  tukar dan suruh user buat sendiri.
- Hantar **fail penuh yang boleh terus upload**, bukan potongan kod.
- Satu fail HTML setiap kad. Tiada zip, tiada folder assets.
- **Uji sendiri sebelum hantar.** Kalau ada yang tak dapat diuji (contoh tiada
  akses ke `gk-bayar.js` sebenar), nyatakan dengan jelas.
- Kalau jumpa bug lain semasa membaiki sesuatu, baiki sekali dan beritahu.
- Bahasa Malaysia santai. Ringkas. Tak perlu ayat bunga.

---

# BAHAGIAN B — REKOD TEMPLATE

Bahagian ni bukan peraturan. Ni rekod apa yang dah wujud dalam repo, supaya
chat baru tak perlu tanya balik.

---

## B1. Inventori repo `Kad-1` (root)

**Fail dikongsi — jangan edit tanpa sebab:**

| Fail | Fungsi |
|---|---|
| `gk-bayar.js` | enjin bayaran (pratonton, pelan, ToyyibPay). MESTI di root |
| `album.js` | jana album PDF. Dikongsi semua kad yang dah dijual — **jangan edit** |
| `lightbox.js` | zoom gambar — pernah hilang dari repo, isu lama |
| `index.html` | homepage, auto-detect borang wujud (HEAD fetch) |
| `bayar.html` | halaman bayaran + QR Premium |
| `semak-kad.html` | "Cari Kad Saya" (cari guna no. telefon) |
| `admin.html`, `affiliate.html`, `diagnostik.html` | admin, program affiliate, ujian rangkaian |
| `api/*` | fungsi serverless ToyyibPay (create-bill, callback, verify, check-qr) |

**Template mengikut kategori:**

| Kategori | Pemilih tema | Borang | Viewer |
|---|---|---|---|
| Hari Jadi | `buat-kad.html` | `buat-kad-merah.html` | `card-merah-1.html` |
| | | `buat-kad-scrapbook.html` | `card-befday-1.html` |
| | | `buat-kad-butterfly.html` | `card-butterfly-1.html` |
| Anniversary | `buat-kad-anniversary.html` | `buat-kad-anniversary-ourstory.html` | `card-anniversary-1.html` |
| | | `buat-kad-suratcinta.html` | `card-suratcinta-1.html` |
| | | `buat-kad-fiona.html` | `card-fiona-1.html` |
| Graduasi & Friends | `buat-kad-graduasi.html` | `buat-kad-graduasi-buku.html` | `card-graduasi-1.html` |
| Bouquet Muka | — (satu tema, RM3, download sahaja) | `bouquet-muka.html` | `card-bouquet-1.html` |
| | | `buat-kad-skrol.html` | `card-skrol-1.html` |

Kategori satu tema tak perlu pemilih — tunggu sampai ada tema kedua (Graduasi dapat tema kedua Sep 2026 → borang lama dinamakan semula `buat-kad-graduasi-buku.html`)
(Seksyen 2).

---

## B2. Template "Fiona" — anniversary mixtape

**Status:** siap dibina, belum jual. Rujukan: TikTok `@flowers_the_bloom`
("Songs for you" mixtape card).

**Konsep:** sampul surat → bunga meletup berpusing → kad mixtape (kaset,
senarai lagu, surat dalam nota mustard).

**Palet:** krim, blush pink, sage green, mustard.
**Keluarga bingkai:** polaroid + jalur filem.

### Fail

```
buat-kad-fiona.html    ← borang, template:'fiona'
card-fiona-1.html      ← viewer (~880KB, semua asset base64)
```

### Medan data (`card_data`)

| Medan | Isi |
|---|---|
| `to`, `from` | nama penerima & penghantar (kepala kad) |
| `letter` | surat — masuk nota mustard, auto-kecil supaya muat |
| `tracks[]` | `{t:tajuk, a:artis, yt:link, mp3:base64}` — maks 3. Lagu 1 auto-main |
| `photo` | gambar utama — masuk bingkai polaroid |
| `photos[]` | gambar tambahan — galeri + album PDF |
| `video` | link YouTube — butang Video |
| `surprise` | kejutan — keluar bila tekan "Tamatkan mixtape" |

### Koordinat slot (dalam viewer)

Semua kedudukan duduk dalam SATU blok `var SLOT={...}` di atas `<script>`.
Bila latar Canva bertukar, kemas kini nombor ni sahaja — tak perlu sentuh
CSS. Nilai = peratus dari gambar latar, `l`/`t` = titik **tengah** slot.

```js
var SLOT={
  foto:  {l:34.00, t:50.71, w:30.86, h:16.21, r:-1.0},   // bingkai polaroid
  nota:  {l:69.10, t:61.84, w:28.16, h:17.25, r: 6.2},   // nota mustard
  lagi:  {l:69.10, t:72.20, r: 6.2},                     // "baca penuh"
  lagu:  {l:50.00, t:81.00, w:60.00},                    // senarai lagu
  butang:{l:50.00, t:92.50}                              // tools + butang
};
```

Latar asal: 941 × 1672 px. Hijau yang Canva keluarkan `#09F017` (bukan tepat
`#00FF00`) — detection guna julat, jadi tak perlu dibetulkan.

### Animasi bunga mekar — cara ia dibuat

1. **Sprite:** latar krim PNG bouquet dibuang guna *flood-fill dari tepi*
   (bukan color-key — kelopak peony putih akan termakan). Lepas tu 6 kelompok
   bunga dipotong guna mask bulat tepi lembut; potongan segi empat nampak
   garis tajam masa berpusing. Kelompok dipilih automatik ikut kepadatan.
2. **Letupan:** ~30 sprite dari tengah, terbang ikut sudut masing-masing,
   pusing 150–420°, saiz 0.04 → 1.9×. Tiga gelombang berperingkat.
3. **Kamera:** seluruh medan `scale` 0.92 → 3.4 sambil pusing −7° → +5°.
   8 bunga besar di belakang tutup ruang kosong atas/bawah (skrin telefon
   tinggi, `vmin` = lebar).
4. **Lebur:** saat 1.9s kad fade in, bunga fade out.

Semua guna `transform` + `opacity` sahaja (GPU). Tiada blur/filter. Auto
turun ke 22 bunga kalau skrin < 420px.

**Bug yang pernah berlaku di sini:** skrin sampul ada `z-index` lebih tinggi
dari medan bunga — latar krim dia menutup habis animasi, bunga langsung tak
nampak. Sampul mesti `z-index:30` (atas kad, bawah medan bunga).

### Prompt Canva — versi guna (v2)

Semua ditulis sebagai **objek fizikal atas meja** (Seksyen 4). Copy blok
satu-satu, jangan paste fail ni penuh.

**Halaman 1 — sampul surat**

```
A top-down flat-lay photograph of a closed kraft paper envelope resting on a
plain cream surface. The envelope sits in the middle, lit softly from above
with a gentle shadow beneath it. A small watercolour spray of dusty pink
blossoms and sage green leaves rests on the envelope flap, and a round mauve
wax seal sits just below the blossoms. The cream surface around the envelope
is completely bare. No writing anywhere in the picture.
```

**Halaman 2 — bunga mekar**

```
A delicate watercolour painting of one lush flower bouquet on a plain cream
background. Blush pink roses, ivory peonies, deep burgundy blooms and soft
sage eucalyptus leaves, gathered into a round cluster, painted in loose
watercolour with visible brush texture. No vase, no wrapping paper, no ribbon.
The cluster sits in the middle with bare cream space all around it. No writing
anywhere in the picture.
```

**Halaman 3 — meja kaset**

```
A top-down flat-lay photograph of a large cream sheet of stationery paper
lying on a soft blush pink vintage floral wallpaper surface. Warm dreamy
daylight falls across it, with sheer pink curtain shadows at the top corners,
a ceramic vase of dried pampas grass and pink roses resting at the bottom
left, and an antique gold picture frame resting at the top right.

Resting on the cream paper, in its upper middle: a sage green cassette tape
with hand-painted botanical leaves across its body. On the cassette's small
paper label, the handwritten words "Songs for you" in elegant serif script.
A pressed dried-flower sticker and a pink gingham fabric bow rest beside the
cassette.

Below the cassette, on the left half of the cream paper: an instant-photo
print with a thick white border, the bottom border noticeably thicker,
tilted a few degrees, with a strip of floral washi tape at its top corner.
Inside the white border: a flat bright magenta rectangle, pure #FF00FF,
completely flat, no texture and no shadow, filling the whole picture opening.

To its right: a torn-edge mustard yellow note card, slightly tilted, with a
small rose pin and a strip of floral washi tape holding its top edge, and the
small printed words "LINER NOTE" near its top. Resting directly on the mustard
paper, filling most of it: a flat bright green rectangle of plain paper, pure
#00FF00, completely flat, no texture and no shadow, with an even margin of
mustard showing all around it.

Lying on the empty cream paper below both: a flat bright green rectangle of
plain paper, pure #00FF00, completely flat, about two thirds as wide as the
cream paper and about one quarter as tall as it is wide.

The top strip of the cream paper and the area below that green rectangle are
completely empty — bare cream paper, nothing resting there. No other writing
anywhere in the picture.
```

**Eksport:** PNG, 1080px lebar, setiap halaman berasingan.

### Apa yang dikod, bukan dari Canva

- Animasi sampul → bunga → kad
- Pemain lagu (YouTube tersembunyi + MP3 base64)
- Galeri gambar, overlay video, popup kejutan
- Toggle EN/BM, teks surat auto-muat
- Semua wiring borang & bayaran

---

## B3. Template "Butterfly" — hari jadi, kolaj taman

**Status:** siap dibina, belum jual. Rujukan: TikTok `@flowers_the_bloom`
(kad surat panjang dengan dinding rama-rama). **Tiru sebijik** — palet, susun
atur dan mekanik ikut video, bukan reka sendiri.

**Konsep:** sampul → dinding rama-rama padat (kamera menyelam tembus) →
kad tatal 3 muka: surat panjang → polaroid bertaburan → panel terapung.

**Palet:** krim `#efe4cf`, hijau rumput, pink peony, **maroon `#6b2737`**
(butang & bar), emas antik. Biru/ungu diharamkan.
**Keluarga bingkai:** polaroid dicat putih, berus kasar, senget.

### Fail

```
buat-kad-butterfly.html   ← borang, template:'butterfly'
card-butterfly-1.html     ← viewer (~1.3MB — 5 latar + 12 sprite, base64)
```

### Halaman Canva (5)

| # | Fail | Kotak | Nota |
|---|---|---|---|
| 1 | sampul | — | sampul kraf, rama-rama + lilac + meterai |
| 2 | rama-rama | — | 12 ekor **berasingan** atas krim rata — untuk potong sprite |
| 3 | surat | 1 hijau (60×65%) | kertas besar senget, peony, ivy, CD taman, bingkai emas |
| 4 | polaroid | 3 magenta (1 **hati**), 1 cyan, 1 kuning | rumput, 2 CD, mawar, bibir vintaj |
| 5 | panel | — | wanita + burung biru, bouquet cosmos kraf; kiri lapang |

### Medan data (`card_data`)

| Medan | Isi |
|---|---|
| `to`, `from` | nama |
| `letter` | surat panjang (≤2000) — **siap isi ayat hari jadi** dalam borang (BM/EN ikut toggle, kekal kalau customer dah ubah, ada butang "Guna ayat asal semula"); petikan atas kertas, penuh dalam popup |
| `p1`, `p2`, `p3` | polaroid, **setiap satu bawah lapisan calar** ("Calar saya"); `p2` = bukaan **hati** (`clip-path`) |
| `pos` | `{p1:{x,y,s}, p2:…, p3:…, surprise_img:…}` — kedudukan laras dari borang (anjakan % dan zum). Tiada = tengah, 1× |
| `surprise_img`, `surprise` | kejutan — **utamanya GAMBAR**, dalam **kotak hadiah** (SVG maroon/emas), tekan → tudung terangkat, 6 rama-rama terbang keluar, kandungan terdedah |
| `video` | YouTube — polaroid cyan, thumbnail + butang main maroon |
| `gallery[]` | galeri bouquet (≤6) — kad maroon gelap dalam panel |
| `song`, `artist`, `yt`, `mp3` | satu lagu, auto-main bila sampul dibuka |
| `map` | `{img, pins:[{x,y,img,title,place,date}]}` — peta kenangan, maks 5 pin |
| `voice` | nota suara base64 (rakaman ~30s ≈ 60–100KB) |

### Koordinat slot (blok `SLOT` dalam viewer)

```js
var SLOT={
  surat:  {l:51.6, t:49.8, w:60.7, h:65.0, r:-4.5},
  p1:     {l:24.4, t:29.4, w:25.0, h:18.3, r:-9.0},
  p2:     {l:47.5, t:46.0, w:20.4, h:13.1, r: 0.5},   // hati
  p3:     {l:26.1, t:71.2, w:25.4, h:18.2, r:-8.0},
  video:  {l:62.2, t:77.2, w:24.6, h:18.0, r: 8.5},
  kejutan:{l:79.4, t:37.8, w:25.2, h:18.4, r: 9.5}    // Scratch me
};
```

Latar 1240×1748. Kotak hati dikesan automatik: isi bounding box 67% (segi
empat ~99%) — ambang `<75%` = hati.

### Mekanik yang dikod (bukan Canva)

- **Dinding rama-rama:** 12 sprite → 8 besar belakang + ~28 letupan 3
  gelombang; kamera `scale` .92→3.4. Tiap ekor kepak sayap sendiri (`scaleX`
  1→.4→1, 110–200ms, dua lapisan elemen supaya tak lawan transform laluan).
- **Scratch me:** canvas kilat logam atas **setiap** slot gambar (p1, p2, p3),
  gosok guna `destination-out`. **Slot senget → koordinat jari kena diputar
  balik** (`pt()` guna sudut slot), kalau tak, calar tersasar. **Ambang ikut
  bentuk:** segi empat 50%, hati 32% — hati cuma ~67% dari kanvas dan jari
  tak boleh sampai penjuru yang terpotong `clip-path`; ambang 55% mustahil
  dicapai. Sentuhan pertama mesti dalam hati (penjuru di luar clip tak
  terima pointer).
- **Laras gambar (borang):** tekan gambar yang dah ada → popup dengan kotak
  **nisbah slot sebenar** (`NISBAH` = lebar/tinggi bukaan dalam piksel latar);
  slot hati tunjuk hati terang + segi empat pudar di belakang supaya nampak
  apa yang tersorok. Seret = anjak, cubit/slider = zum 1–3×, klamp supaya
  tiada celah (`|x|,|y| ≤ (s−1)·50`). Disimpan `{x,y,s}`; borang & viewer guna
  **CSS transform yang sama** — `translate(-50%,-50%) translate(x%,y%)
  scale(s)` — jadi pratonton = hasil. **`clip-path` mesti atas BEKAS, bukan
  atas `img` yang di-transform** — kalau tak, bentuk hati ikut membesar bila
  zum.
- **Kotak hadiah:** SVG dua kumpulan (`.tudung`, `.badan`), `transform-box:
  fill-box` supaya putaran ikut kotak sendiri. Tekan → tudung naik & pusing,
  badan turun & pudar, 6 sprite rama-rama terbang keluar, lapisan hilang.
- **Tempo:** semua durasi intro didarab `TEMPO` (1.7). Ubah satu nombor.
- **Rama-rama berkeliaran:** lapisan `#hidup` `position:fixed`, 5–7 ekor,
  laluan 5 titik rawak 16–26s ulang `alternate`, kepak sendiri, `pointer-
  events:none` supaya tak halang sentuhan. Nampak atas ketiga-tiga muka.
- **Hati:** `clip-path:url(#hatiClip)` (SVG `objectBoundingBox`), sama dalam
  borang untuk pratonton kotak.
- **Surat:** auto-kecil font supaya muat kertas, mask pudar bawah, bar maroon
  "Tekan untuk baca lagi ♡" → popup "Sekeping nota" dengan butang "Selesai".
- **Kad tatal:** 3 `section` `100dvh` + `scroll-snap`; latar `contain` dalam
  `.page` beraspek 1240/1748, letterbox guna latar kabur.
- **Sampul kena fade** (`opacity`) serentak dengan kad masuk — bukan
  `display:none` mengejut; latar krimnya tak lut.

### Sprite rama-rama — cara potong

Flood-fill dari tepi **gagal** (latar krim Canva ada gradasi halus, tersekat
di tengah). Guna **jarak warna dari latar** sebagai alpha (`clip((d-20)/38)`)
dengan latar dianggar dari blur berat imej itu sendiri. Lepas tu **tampal
lubang dalaman** (kawasan lut sinar yang tak bersambung ke tepi sprite = lubang
sayap pucat → set legap). Tanpa langkah ni sayap berlubang hitam.

### Peta kenangan & nota suara (Sep 2026)

- **Peta = screenshot customer sendiri**, bukan peta geografi. Tiada data
  geometri negara dalam persekitaran ni (npm/pip untuk pakej peta disekat
  oleh dasar keselamatan; lakar sendiri dari ingatan nampak buruk). Customer
  screenshot Google Maps → upload → tekan atas peta untuk letak pin. Lebih
  fleksibel juga: kenangan di luar negara pun boleh.
- Pin disimpan sebagai **peratus** (`x`,`y`) dari saiz peta, jadi kekal tepat
  pada mana-mana saiz skrin. Tekan pin dalam viewer → kad detail naik dengan
  gambar + tarikh + tajuk + tempat (macan f036 dalam video), dan
  `scrollIntoView` supaya tak tersorok bawah fold. Butang +/− zum `scale()`
  1–2.6×.
- **Nota suara:** `MediaRecorder` opus 32kbps, had 30 saat (~60–100KB).
  Fallback upload fail (had 600KB) untuk browser tanpa MediaRecorder. Viewer
  ada bar gelombang yang terisi ikut `ontimeupdate` + kiraan detik menurun.
  Nota suara dan lagu **saling memberhentikan** — tak boleh dua bunyi serentak.
- **Panel muka 3 jadi boleh tatal** (`max-height:80%; overflow-y:auto`,
  scrollbar disorok) sebab sekarang ada sampai 5 kad.
- **Kad sempit (panel 52%) → susun dua baris**, bukan satu baris: `display:grid`
  dengan `grid-template-areas:'btn tx masa' 'btn bar bar'`. Satu baris buat
  tajuk terpotong jadi "Not…".
- **Jangan set `style.display='flex'` inline** pada kad yang CSS-nya `grid` —
  inline menang, grid mati senyap. Guna `style.display=''` untuk tunjuk.
- **Borang ada penunjuk saiz kad** (`kiraSaiz()`): kira `JSON.stringify` dan
  beri amaran merah kalau >3.8MB, sebab had baris Supabase ~4.5MB.

### Tak dibuat

- Tiada. Semua elemen dari video reference sudah dibina.

---

## B4. Template "Skrol" — graduasi, skrol ijazah + kawan

Konsep: skrol bergulung diikat reben navy + meterai emas. Customer TARIK reben
(drag, bukan tekan) → reben lerai 7 keping → DINDING bunga kering + topi
graduasi meletup dari skrol memenuhi skrin (3 gelombang, corak sama dengan
dinding rama-rama Butterfly) → kamera selam masuk (scale 3.4× + pudar) →
skrol terbuka di sebalik (rod atas naik, rod bawah turun) → surat.
Kemudian 4 muka scroll-snap: graduan (4 bingkai emas berukir), kawan (6
bingkai nipis, tekan → popup gambar + nota macam tandatangan buku tahunan),
video + kejutan bermeterai (tekan meterai → pecah → gambar), panel muzik.
Topi graduasi hanyut atas kad sepanjang masa (tassel berayun — lapisan luar
laluan, lapisan dalam ayun, sama corak dengan sayap rama-rama Butterfly).

### Fail
```
buat-kad-graduasi.html   ← PEMILIH tema (baru) — borang lama (Memory Book, scrapbook selak 16 gambar) jadi buat-kad-graduasi-buku.html
buat-kad-skrol.html      ← borang, template:'skrol'
card-skrol-1.html        ← viewer (~1.2MB, semua aset base64 webp)
```

### Halaman Canva (8 fail, 1240×1748)
1 gulung (skrol kosong TANPA reben, latar navy) · 2 kepingan reben + rod (latar
putih, 9 keping) · 3 topi (latar putih, 10 — 1 terpotong tepi, guna 9) ·
3b bunga kering (latar putih, 14 keping: 5 ros, 4 laurel/olive, 2 baby's
breath, 2 daun emas, 1 reben) — potong dengan ambang lebih tinggi (30/70)
+ buang piksel min>225 supaya tiada sisa putih di tepi ros ·
4 surat kolaj (1 hijau) · 5/6/7 graduan/kawan/video versi KERTAS KOSONG
(bingkai sempurna) · 8 latar kolaj tanpa bingkai.

**Pengajaran penting:** prompt kolaj + bingkai + kotak dalam satu halaman
GAGAL — Canva tampal kotak macam pelekat, tak isi bukaan (kawan: kotak
melintas dua bingkai). Penyelesaian: bingkai dari versi kertas kosong
DITINDIH atas latar kolaj dengan Python (`prep_sk.py` → `topeng_bingkai`
+ `tindih`). Koordinat slot kekal, latar jadi kaya. Kalau nak kolaj, minta
latar dan bingkai BERASINGAN.

### Medan data (`card_data`)
`to` (nama graduan) · `from` (default "Kami semua") · `tahun` · `kursus`
(2 baris) · `letter` · `p1..p4` · `k1..k6` + `kn1..kn6` (nama) + `kt1..kt6`
(nota) · `surprise_img` · `surprise` · `video` · `yt` `mp3` `song` `artist` ·
`pos{}` (kunci: p1..p4, k1..k6, surprise_img). Gambar dikecilkan 760px q.78
(11 gambar → jaga had 4.5MB).

### Koordinat slot (blok `SLOT` dalam viewer, % dari 1240×1748)
surat hijau l50 t50.6 w69.2 h66.7 · graduan 4 slot ~28×18% tilt ±4–6° ·
kawan 6 slot ~29.5×16.8% tilt ±4–5° · video cyan l51 t28 w63.6 h28 r-5.9 ·
kejutan kuning l52 t79 w33 h23. `BESAR=1.035` besarkan slot foto untuk
tutup pinggir magenta anti-alias (bingkai graduan ada sisa ungu 1–2px).
Badan gulung dalam gambar 1: x17–83%, y41.5–52% → reben diletak di situ.

### Mekanik yang dikod
- Drag reben: pointer events, >58px → `lerai()`; lepas awal → spring balik.
  `muzik()` dipanggil DALAM `lerai()` (gesture).
- Rod JANGAN diputar — bar panjang berputar nampak macam kipas. Rod cuma
  translate.
- `#bukaan` (skrol terbuka dalam intro) = `.page` saiz sama dengan muka 1;
  bila penuh, intro pudar dan `#kad` muncul di muka 1 — latar muka 1 = gambar
  gulung (navy + cahaya) supaya peralihan tak nampak.
- CSS animation `pul` pada `.sLagi` tindih `opacity:0` inline → baris tu
  muncul awal masa unroll. Fix: `#bukaanIsi .sLagi{animation:none}`.
- Kejutan: `.tutupK` (meterai + "Tekan meterai") di atas gambar; tekan 1 →
  meterai pecah (WAAPI), tekan 2 → lightbox.
- Panel muka 5 `align-items:center` (bukan flex-start) supaya kad muzik di
  tengah bila kandungan pendek.

### Tak dibuat
Peta kenangan & nota suara (ada dalam Butterfly) — sengaja tinggal supaya
template ni ringan. Parallax bingkai tak dibuat (bingkai ditindih ke dalam
gambar latar, bukan lapisan berasingan).

---

## B5. Produk "Bouquet Muka" — bouquet sticker (bukan kad)

Produk berasingan, RM3, **download sahaja** — tiada link kongsi, tiada QR kad,
tiada komisen affiliate. Fail: `bouquet-muka.html` (borang) + `card-bouquet-1.html`
(viewer download). Wiring bayar: `plans:{bouquet:{rm:3,…}}`, `btn:'Bayar RM3 & download'`,
`qr:true`, **tiada `previewEl`** (butang pratonton gk-bayar akan bocorkan gambar bersih).

### Mod compositing
Satu-satunya mod yang digunakan sekarang ialah **`mode:'sticker'`**. Mod lama
(muka jadi pusat bunga, bulatan magenta dari Canva) dibuang Sep 2026 — user kata
"nampak macam tampal". Jangan hidupkan semula tanpa diminta.

Aliran sticker:
1. `cutPerson(img)` — **MediaPipe Selfie Segmentation** dari CDN jsdelivr
   (`@mediapipe/selfie_segmentation@0.1`), dimuat malas pada generate pertama.
   Mask MediaPipe kadang bawa keyakinan dalam **alpha**, kadang dalam kecerahan —
   kod kena kesan sendiri (lihat `cutPerson`), kalau salah keluar kotak penuh.
   Tinggi dipotong pada `y0 + 1.4 × lebar` supaya berhenti paras dada, bukan pinggang.
2. `makeSticker(cut,warna)` — garis putih tebal + garis warna di luar, dibuat dengan
   36 salinan cut yang dianjak pada bulatan (bukan `shadow`, sebab shadow tak tebal sekata).
3. `lukisLetak(...)` — latar → sticker → **overlay** (bunga hadapan, PNG/WebP alpha)
   → **lukis semula kepala** setiap sticker di atas overlay supaya daun/lollipop tak
   melintas muka. Langkau lukis-semula kalau kepala memang di atas garis overlay
   (kalau tak, baris belakang akan timpa baris depan).

### Overlay — cara buat dari gambar Canva
Overlay = gambar penuh yang sama, alpha = siluet jambangan × ramp menegak.
Siluet dikira di Python: latar kain pink ada **V tinggi + S rendah**; jambangan
**V<200 atau S>88**. Ambil komponen bersambung terbesar, tutup lubang (`MORPH_CLOSE` 41px),
blur 2px. Crop overlay dari `overlayY` ke bawah untuk jimat saiz.
`overlayY` rendah (≈0.42) = sticker besar tindih atas bunga (gaya yang user mahu).
`overlayY` tinggi (≈0.12) = kepala kecil menjenguk dari dalam jambangan — **ditolak user**.

### Editor susunan (customer)
Selepas Generate, template sticker **tidak terus siap** — customer dapat kanvas
`#susunCanvas`: tap pilih, seret alih, cubit 2 jari besar/kecil + pusing, plus
butang ＋ − ↺ ↻ ⇄ Depan Belakang, "🔄 Gambar lain" (kalau >1 muka), "🎲 Susun auto".
Tekan **"✨ Kemaskan & pratonton"** → `renderFinal()` render semula pada resolusi
penuh (kanvas editor hanya 720px lebar) → tanda air → Langkah 4 bayar.
Sticker di-cache (`stickerCache`) ikut set gambar + template, jadi susun semula
tak perlu potong badan sekali lagi.

### Template sedia ada
| id | Latar | overlayY | Nota |
|---|---|---|---|
| `valentine-roses` | Ros pink + daisy, bokeh hati | 0.36 | 5 slot, siluet bunga |
| `lace-butterfly` | Bunga lace mutiara + rama-rama, kraft | 0.42 | 5 slot, sticker besar |

Editor template (admin) sokong mod sticker: pilih "Sticker badan (potong auto)",
slot disimpan sebagai `{x,y,w}` (bukan `{x,y,r}`), `w` = lebar sticker (% lebar imej).
